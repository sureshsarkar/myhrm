
<link   href="<?= base_url()?>assets/css2/bb.css" rel="stylesheet" >
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css" />
        <!-- Libs CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/bootstrap.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/fonts/font-awesome/css/font-awesome.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/vendor/flexslider/flexslider.css" media="screen" />
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/vendor/fancybox/jquery.fancybox.css" media="screen" />
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/home.css">
        <!-- Theme CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/theme.css">
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/theme-elements.css">

        <!-- Current Page Styles -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/vendor/revolution-slider/css/settings.css" media="screen" />
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/vendor/revolution-slider/css/captions.css" media="screen" />
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/vendor/circle-flip-slideshow/css/component.css" media="screen" />

        <!-- Custom CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/custom.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

        <!-- Skin -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/skins/blue.css">
        
        <!-- Responsive CSS -->
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/bootstrap-responsive.css" />
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/theme-responsive.css" />
        <!--stats-->
        <link rel="stylesheet" href="<?= base_url()?>assets/css2/stats.css">

        

<div role="main" class="main" style="border-top:1px solid #e4e5e5;">
<div id="content" class="content full">

<div class="slider-container">
            <div class="slider" id="revolutionSlider">
                            <ul>
<li data-transition="fade" data-slotamount="10" data-masterspeed="300">
                        <img src="<?= base_url()?>assets/images/slides/slide-bg1.jpg" data-fullwidthcentering="on" alt=" Digital Marketing Company Noida" title=" Digital Marketing Company Noida"></li>
    <li data-transition="fade" data-slotamount="10" data-masterspeed="300">
<img src="<?= base_url()?>assets/images/slides/slide-bg2.jpg" data-fullwidthcentering="on" alt="Web Designing Company In Noida" title="Web Designing Company In Noida"></li>
<li data-transition="fade" data-slotamount="10" data-masterspeed="300">
<img src="<?= base_url()?>assets/images/slides/slide-bg3.jpg" data-fullwidthcentering="on" alt="Website Designing Company Noida" title="Website Designing Company Noida"></li>

<li data-transition="fade" data-slotamount="10" data-masterspeed="300">
<img src="<?= base_url()?>assets/images/slides/slide-bg4.jpg" data-fullwidthcentering="on" alt="Web Designing Company in Noida" title="Web Designing Company in Noida"></li>

<li data-transition="fade" data-slotamount="10" data-masterspeed="300">
<img src="<?= base_url()?>assets/images/slides/slide-bg6.jpg" data-fullwidthcentering="on" alt="Website Design Company in Noida" title="Website Design Company in Noida"></li>


<li data-transition="fade" data-slotamount="10" data-masterspeed="300">
<img src="<?= base_url()?>assets/images/slides/slide-bg5.jpg" data-fullwidthcentering="on" alt="Website Designing Company in Noida" title="Website Designing Company in Noida"></li>
</ul>
</div>
</div>
<div class="home-intro" style="margin-bottom:0px; background-color:#F9F9F9;    padding: 0px 0 0px 0;">
<div class="container" >
<p style="color:#373737; font-size:18px; padding-left:20px; padding-top:25px; max-width:1200px;"><marquee onmouseover="this.stop();" onmouseout="this.start();" scrolldelay="90">
    <a href="">TechCentrica® has achieved a Maturity Level 3 rating on the <b style="color: #db2848;">CMMI LEVEL</b> </a>

<a href=""  style="padding-left:25px; ">"<b style="color: #db2848;">IIM Lucknow</b> - Incubator Picked off By TechCentrica"</a>
<a href=""  style="padding-left:25px; ">“TechCentrica Crowned <b  style="color: #db2848;">IIMT</b> Through Online Marketing”</a> 
<a href=""  style="padding-left:25px; ">Association of Institute of <b  style="color: #db2848;">Company Secretaries of India</b> with TechCentrica prolongs.</a> 
<a href=""  style="padding-left:25px; ">TechCentrica’s Heartful Thanks to <b  style="color: #db2848;">India Infrastructure Finance Company Limited</b> (A Govt. of India Enterprise).</a>
<a href=""  style="padding-left:25px; ">“Techcentrica <b  style="color: #db2848;">Crosses the Road</b> of Digital account”</a>
<a href=""  style="padding-left:25px; ">“<b style="color: #db2848;">Arunanchal University</b> Joins Its Hands With TechCentrica”</a>
<a href=""  style="padding-left:25px; ">"TechCentrica To Boost Searches For <b style="color: #db2848;">Neptune</b> On All Planets"</a>
<a href=""  style="padding-left:25px; ">"TechCentrica To Publish & Uplift <b style="color: #db2848;">AKG GROUP</b> On Internet"</a>
<a href=""  style="padding-left:25px; ">Team TechCentrica would like to thanks <b style="color: #db2848;"> Sam India</b> for their trust and confidence on us for their website.</a>
<a href=""  style="padding-left:25px; "><b style="color: #db2848;">Teenager Bra</b> selected TechCentrica for it’s adaptive website development & online presence.
</a>
</marquee></p>
</div>
</div>
<div class="home-intro">
<div class="container">

<div class="row">
<div class="span8">
<p>Our client relationships <em style="color:#FFF;">do not start at 9AM and end at 6PM </em> — they stay with us to continually receive the quality service they deserve.</p>
</div>

<div class="span4">
<div class="get-started">
<a href="https://techcentrica.com/contact-us.html" style="cursor:pointer;"    class="btn btn-large btn-primary">Get In Touch</a>
</div>
</div>
</div>
</div>
</div>
<div class="container">

    <div class="row center">
        <div class="span12">
            <h1 class="short">
            We <strong class="inverted">Love design.</strong> We Love technology. But what we love most is creating the <strong class="inverted"> Brand "You".</strong></h1>
            <p class="featured lead">TechCentrica has emerged as one of the <strong> Leading Digital Marketing </strong> company which is based in Noida  with presence in Melbourne, Australia. Specializing in high-end services in the spectrum of  <a href="Web-Solutions.html" title="Website Designing Company In Delhi, NCR">Web Design & Development</a>, <a href="Digital-Marketing.html" title="Digital Marketing Company In Noida">Digital Marketing</a>,   <a href="https://techcentrica.com/SEO.html" title="SEO Company In Noida">Search Engine Marketing</a>  & <a href="ORM.html" title="Online Reputation Marketing Company Noida">Online Reputation Management</a>  . TechCentrica believes in partnering with the customers over the long-term through flexible business procedure and delivery models.</p>
        </div>
    </div>

</div>

<div class="home-concept">
    <div class="container">
        <div class="row center">
            <span class="sun"></span>
            <span class="cloud"></span>
            <div class="span2 offset1">
                <div class="process-image">
                    <img src="<?= base_url()?>assets/images/home-concept-item-1.png" alt="Web Designing Company In Noida" title="Web Designing Company In Noida" />
                    <strong>Strategy</strong>
                </div>
            </div>
            <div class="span2">
                <div class="process-image">
                    <img src="<?= base_url()?>assets/images/home-concept-item-2.png" alt="Website Designing Company in Noida" title="Website Designing Company in Noida"/>
                    <strong>Planning</strong>
                </div>
            </div>
            <div class="span2">
                <div class="process-image">
                    <img src="<?= base_url()?>assets/images/home-concept-item-3.png" alt="Website Development Company in NCR" title="Website Development Company in NCR" />
                    <strong>Build</strong>
                </div>
            </div>
            <div class="span4 offset1">
                <div class="project-image">
                    <div id="fcSlideshow" class="fc-slideshow">
                        <ul class="fc-slides">
                            <li><a href="#"><img src="<?= base_url()?>assets/images/projects/project-home-1.jpg" alt="Website Design Company In Noida" title="Website Design Company In Noida" /></a></li>

                                <li><a href="#"><img src="<?= base_url()?>assets/images/projects/project-home-2.jpg" alt="Web Development Company in NCR" title="Web Development Company in NCR" /></a></li>
                        <li><a href="#"><img src="<?= base_url()?>assets/images/projects/project-home-3.jpg" alt="Website Development Company in Noida" title="Website Development Company in Noida" /></a></li>
                        </ul>
                    </div>
                    <strong class="our-work">Our Work</strong>
                </div>
            </div>
        </div>
        <!-- <hr class="tall" /> -->
    </div>
</div>
<section class="bg2 cova" style="    width: 100%;margin-right: auto;margin-left: auto;margin-top: 100px;" > 
<div  style="text-align: center;">
    <h1 style="    margin-bottom: -6px;
    margin-top: 50px;">What We  <strong>Do!</strong></h1>
  </div>
    <div class="row blocks_wrapper" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
        <div class="col-md-4">
            <div class="box_wrap">
                <img src="<?= base_url()?>assets/images/marketing.png" alt="Best SEO Plans" />
                <h3 class="h2">Digital Marketing Management</h3>
                <p>Understanding digital marketing is not difficult these days, even for a non-technical person. Digital marketing is basically a type of promotional technique that has been mainly employed on digital devices.</p>
                <a href="https://techcentrica.com/Digital-Marketing.html"><button class="common_home_btn small_btn" type="button">INCREASE LEADS / SALES</button></a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="box_wrap">
                <img src="<?= base_url()?>assets/images/search-engine-optimization.png" alt="Link Building" />
                <h3 class="h2">Search Engine Management</h3>
                <p>Search Engine Optimization is fundamental to success. Search Engine Optimization (SEO) is a technique that employs a combination of factors to help your website achieve higher rankings in major search engines.</p>
                <a href="https://techcentrica.com/SEO.html"><button class="common_home_btn small_btn" type="button">GET TOP RANKING</button></a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="box_wrap">
                <img src="<?= base_url()?>assets/images/social-media (1).png" alt="On Page SEO" />
                <h3 class="h2">Social Media Management</h3>
                <p>Social Media Promotion is the process of generating public opinion through use of social media like online communities, websites and various other medium <br>of communication over internet.</p>
                <a href="https://techcentrica.com/SMO.html"><button class="common_home_btn small_btn" type="button">INCREASE ENGAGEMENT</button></a>
            </div>
        </div>
    </div>
    <div class="row blocks_wrapper" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
        <div class="col-md-4">
            <div class="box_wrap">
                <img src="https://cdn-icons-png.flaticon.com/128/2720/2720867.png" alt="Best SEO Plans" />
                <h3 class="h2">Online Reputation Management</h3>
                <p>In today’s technology driven world, one can easily do away with all kinds of negative comments and negative propaganda against one’s business online. So, Now it's time to get rid of all online negativity in one <br> shot.</p>
                <a href="https://techcentrica.com/ORM.html"><button class="common_home_btn small_btn" type="button">BUILDING YOUR REPUTATION</button></a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="box_wrap">
                <img src="https://cdn-icons-png.flaticon.com/128/1162/1162499.png" alt="Link Building" />
                <h3 class="h2">E-Commerce Solutions</h3>
                <p>E-commerce and stores help in magnifying the reach of a business to a great customer base on a global scale. We provide various e-commerce solutions like development, designing, marketing, brand awareness <br>etc.</p>
                <a href="https://techcentrica.com/E-Commerce.html"><button class="common_home_btn small_btn" type="button">GROW YOUR SALES</button></a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="box_wrap">
                <img src="https://cdn-icons-png.flaticon.com/128/7991/7991055.png" alt="On Page SEO" />
                <h2   style="    color: #000000;
                font-size: 21px;
                font-weight: 700;
                 
                margin: 4px 0;">WEB DESIGN & DEVELOPMENT</h2>
                <p>A website should not just draw attention. The role of a website is to attract and engage the user, as well as communicate your brand and raise awareness about<br> a product or service with utmost accuracy and quality.</p>
                <a href="https://techcentrica.com/Web-Solutions.html"><button class="common_home_btn small_btn" type="button">UPGRADE YOUR DESIGN</button></a>
            </div>
        </div>
        
    </div>

    <div class="row blocks_wrapper" data-aos="fade-up" data-aos-delay="300" data-aos-duration="1000">
        <div class="col-md-4">
            <div class="box_wrap">
                <img src="<?= base_url()?>assets/images/content-creator.png" alt="Best SEO Plans" />
                <h3 class="h2">Content Creation</h3>
                <p>Our Content Writing Services are developed in such a way that people gets engaged to every content we present. This is our way of connecting right people with your brand by touching their emotional nerve.</p>
                <a href="https://techcentrica.com/Content-Creation.html"><button class="common_home_btn small_btn" type="button">ENGAGE VISITORS</button></a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="box_wrap">
                <img src="<?= base_url()?>assets/images/mobile-app.png" alt="Link Building" />
                <h3 class="h2"> Application Marketing
                </h3>
                <p>Techcentrica brings together a complete strategy for promoting your mobile app for huge number of downloads. In this connected world, users are more into digital devices and here we harness the power of digital media.</p>
                <a href="https://techcentrica.com/Mobile-Marketing.html"><button class="common_home_btn small_btn" type="button">INCREASE DOWNLOAD</button></a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="box_wrap">
                <img src="<?= base_url()?>assets/images/web.png" alt="On Page SEO" />
                <h2   style="    color: #000000;
                font-size: 21px;
                font-weight: 700;
                 
                margin: 4px 0;"> PORTAL DEVELOPMENT</h2>
                <p>TechCentrica have pioneered the domain of portal development in the country with successful execution of top line portals that incorporate the latest technology and most interactive options to attract the users. </p>
                <a href="https://techcentrica.com/Portal-Development.html"><button class="common_home_btn small_btn" type="button">GROW YOUR SALES</button></a>
            </div>
        </div>
        
    </div>
</section>
<!--container-->
    
        <section id="latest-work">
            <div class="container">
                <div class="row">
                    <div class="span12" style="    margin-bottom: -6px;
                    margin-top: 60px;">
                        <h1 >Passionate about <strong>crafting modern</strong> and usable design!</h1>
                        <h4 class="lead tall" style="color:#000000; font-size:18px; text-align:center;">Our web & online marketing work speaks for itself. We deliver an outstanding service custom-tailored to each and every one of our clients.</h4>
                    </div><!--col-->    
                </div><!--row-->    
                <div class="row">
                    <div class="span6">
                        <div class="img-hover">
                            <img src="<?= base_url()?>assets/images/latest-work/1-top.jpg" alt="Web Development Company in Noida">
                        </div>  
                    </div>
                    <div class="span3">
                        <div class="img-hover">
                            <img src="<?= base_url()?>assets/images/latest-work/9.jpg" alt="Web Development Company Noida">
                        </div>
                    </div>
                    <div class="span3">
                        <div class="img-hover">
                            <img src="<?= base_url()?>assets/images/latest-work/7.jpg" alt="Website Company in Noida">
                        </div>
                    </div>          
                </div><!--row-->
                
                <div class="row padding-20">
                    <div class="span3">
                        <div class="img-hover">
                            <img src="<?= base_url()?>assets/images/latest-work/5.jpg" alt="Website Development Company Noida
                            ">
                        </div>  
                    </div>
                    <div class="span3">
                        <div class="img-hover">
                            <img src="<?= base_url()?>assets/images/latest-work/6.jpg" alt="Website Development Company in Noida
                            ">
                        </div>
                    </div>
                    <div class="span6">
                        <div class="img-hover">
                            <img src="<?= base_url()?>assets/images/latest-work/ICSINew.jpg" alt="Web Development Services in Noida
                            ">
                        </div>
                    </div>
                        
                        
                </div><!--row-->
                <div class="row padding-20">
                    <div class="span3">
                        <div class="img-hover">
                            <img src="https://techcentrica.com/images/portfolio/06.jpg" alt="Website Designing Company Noida
                            ">
                        </div>  
                    </div>
                    <div class="span3">
                        <div class="img-hover">
                            <img src="https://techcentrica.com/images/portfolio/04.jpg" alt="Web Designing Company in Noida
                            ">
                        </div>
                    </div>
                    <div class="span3">
                        <div class="img-hover">
                            <img src="https://techcentrica.com/images/portfolio/08.jpg" alt="Website Design Company In Noida
                            ">
                        </div>
                    </div>
                    <div class="span3">
                        <div class="img-hover">
                            <img src="https://techcentrica.com/images/portfolio/09.jpg" alt="Website Designing Company in Noida
                            ">
                        </div>
                    </div>      
                        
                </div><!--row-->    
                
                <!--row-->
                
            </div><!--container-->  
        </section>
    <!--=====================================
                client-logo
    ========================================-->
    <section class="whitesection_wrap dots_btm_left halfcricle_wrap bg2"style="padding: 80px;">
       <div class="custom_container">
           <div class="row align-items-center">
               <div class="col-md-6">
                   <label>TECHCENTRICA CLIENTS</label>
                   <h2 class="h1" style="text-align: left;">Unveil The  <span>Collaboration.</span> <span class="box_text">Let’s Work & Grow Together.</span></h2>
                    <p>We @TechCentrica believe in serving the best experience to our clients with most intutive and most versatile experience , we aim at providing more than what is required.</p>
                    <a href="https://techcentrica.com/Clientele.html"><button class="common_home_btn" type="button">LEARN MORE<img src="<?= base_url()?>assets/images/arrow-right-white.svg" alt="Icon" /></button></a>

               </div>
               <div class="col-md-6">
                   <lottie-player src="https://assets2.lottiefiles.com/packages/lf20_dBF8frvgma.json" background="transparent" speed="1" loop autoplay class="big_img" alt="Web Designing Company in Noida" title="Web Designing Company in Noida"></lottie-player>
               </div>
               <div class="col-md-12">
             
                </div>
           </div>
       </div>
       <!-- client-section END-->
   </section>





