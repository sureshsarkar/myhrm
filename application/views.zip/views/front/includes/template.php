<?php $this->load->view('front/includes/header');?>
<?php $this->load->view('front/includes/menu');?>
<?php $this->load->view($file);?>
<?php $this->load->view('front/includes/footer');?>