/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'eu', {
	border: 'Erakutsi markoaren ertza',
	noUrl: 'Idatzi iframe-aren URLa, mesedez.',
	scrolling: 'Gaitu korritze-barrak',
	title: 'IFrame-aren propietateak',
	toolbar: 'IFrame-a',
	tabindex: 'Remove from tabindex' // MISSING
} );
