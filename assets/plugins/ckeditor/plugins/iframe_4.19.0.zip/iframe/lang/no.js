/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'no', {
	border: 'Viss ramme rundt iframe',
	noUrl: 'Vennligst skriv inn URL for iframe',
	scrolling: 'Aktiver scrollefelt',
	title: 'Egenskaper for IFrame',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
